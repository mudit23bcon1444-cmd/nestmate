// controllers/authController.js — authentication & profile management logic

const bcrypt = require('bcrypt');
const { getDB } = require('../database');
const { sendOTP } = require('../utils/sms');

// POST /api/auth/register
exports.register = async (req, res) => {
  try {
    const { name, email, password, role } = req.body;

    if (!name || !email || !password) {
      return res.status(400).json({ error: 'Name, email, and password are required.' });
    }

    const allowedRoles = ['student', 'owner'];
    const userRole = allowedRoles.includes(role) ? role : 'student';

    const db = getDB();

    const existing = db.prepare('SELECT id FROM users WHERE email = ?').get(email.toLowerCase().trim());
    if (existing) {
      return res.status(409).json({ error: 'An account with this email already exists.' });
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    const result = db.prepare(
      'INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)'
    ).run(name.trim(), email.toLowerCase().trim(), hashedPassword, userRole);

    const newUser = {
      id: result.lastInsertRowid,
      name: name.trim(),
      email: email.toLowerCase().trim(),
      role: userRole
    };

    req.session.user = newUser;

    return res.status(201).json({ message: 'Account created successfully.', user: newUser });
  } catch (err) {
    console.error('Register error:', err);
    return res.status(500).json({ error: 'Something went wrong. Please try again.' });
  }
};

// POST /api/auth/login
exports.login = async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ error: 'Email and password are required.' });
    }

    const db = getDB();
    const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email.toLowerCase().trim());

    if (!user) {
      return res.status(401).json({ error: 'Invalid email or password.' });
    }

    const passwordMatch = await bcrypt.compare(password, user.password);
    if (!passwordMatch) {
      return res.status(401).json({ error: 'Invalid email or password.' });
    }

    const sessionUser = {
      id: user.id,
      name: user.name,
      email: user.email,
      role: user.role
    };

    req.session.user = sessionUser;

    return res.status(200).json({ message: 'Logged in successfully.', user: sessionUser });
  } catch (err) {
    console.error('Login error:', err);
    return res.status(500).json({ error: 'Something went wrong. Please try again.' });
  }
};

// POST /api/auth/logout
exports.logout = (req, res) => {
  req.session.destroy((err) => {
    if (err) {
      console.error('Logout error:', err);
      return res.status(500).json({ error: 'Could not log out. Please try again.' });
    }
    res.clearCookie('connect.sid');
    return res.status(200).json({ message: 'Logged out successfully.' });
  });
};

// GET /api/auth/me
exports.getMe = (req, res) => {
  if (req.session && req.session.user) {
    return res.status(200).json({ user: req.session.user });
  }
  return res.status(401).json({ error: 'Not authenticated.' });
};

// POST /api/auth/send-otp
exports.sendOtp = async (req, res) => {
  try {
    const { phone } = req.body;
    if (!phone) return res.status(400).json({ error: 'Phone number is required.' });

    const db = getDB();
    const existingRecord = db.prepare('SELECT * FROM otp_store WHERE phone = ?').get(phone);

    if (existingRecord) {
      if (existingRecord.locked_until && existingRecord.locked_until > Date.now()) {
        return res.status(403).json({ error: 'Phone locked. Try again after 15 minutes.' });
      }

      if (existingRecord.last_sent_at) {
        const elapsed = Date.now() - existingRecord.last_sent_at;
        if (elapsed < 60000) {
          const remainingSeconds = Math.ceil((60000 - elapsed) / 1000);
          return res.status(429).json({ error: `Please wait ${remainingSeconds}s before requesting again.` });
        }
      }
    }

    const otp = Math.floor(100000 + Math.random() * 900000).toString();
    const expiresAt = Date.now() + 5 * 60 * 1000;

    db.prepare(`
      INSERT INTO otp_store (phone, otp, expires_at, last_sent_at, attempt_count, locked_until) 
      VALUES (?, ?, ?, ?, 0, 0)
      ON CONFLICT(phone) DO UPDATE SET 
        otp=excluded.otp, 
        expires_at=excluded.expires_at, 
        last_sent_at=excluded.last_sent_at,
        attempt_count=0,
        locked_until=0
    `).run(phone, otp, expiresAt, Date.now());

    await sendOTP(phone, otp);

    db.prepare('INSERT INTO otp_logs (phone, action, ip_address) VALUES (?, ?, ?)')
      .run(phone, 'sent', req.ip);

    return res.status(200).json({ message: 'OTP sent successfully.' });
  } catch (err) {
    console.error('Send OTP error:', err);
    return res.status(500).json({ error: 'Failed to send OTP.' });
  }
};

// POST /api/auth/verify-otp
exports.verifyOtp = async (req, res) => {
  try {
    const { phone, otp } = req.body;
    if (!phone || !otp) return res.status(400).json({ error: 'Phone and OTP are required.' });

    const db = getDB();
    const record = db.prepare('SELECT * FROM otp_store WHERE phone = ?').get(phone);

    if (record && record.locked_until && record.locked_until > Date.now()) {
      return res.status(403).json({ error: 'Phone locked. Try again after 15 minutes.' });
    }

    if (!record || record.otp !== otp || Date.now() > record.expires_at) {
      if (record) {
        const newAttempts = (record.attempt_count || 0) + 1;
        if (newAttempts >= 5) {
          db.prepare('UPDATE otp_store SET attempt_count = ?, locked_until = ? WHERE phone = ?')
            .run(newAttempts, Date.now() + 15 * 60 * 1000, phone);
          db.prepare('INSERT INTO otp_logs (phone, action, ip_address) VALUES (?, ?, ?)')
            .run(phone, 'locked', req.ip);
          return res.status(403).json({ error: 'Phone locked. Try again after 15 minutes.' });
        } else {
          db.prepare('UPDATE otp_store SET attempt_count = ? WHERE phone = ?')
            .run(newAttempts, phone);
          db.prepare('INSERT INTO otp_logs (phone, action, ip_address) VALUES (?, ?, ?)')
            .run(phone, 'failed', req.ip);
        }
      }

      if (!record || record.otp !== otp) {
        return res.status(401).json({ error: 'Invalid OTP.' });
      }
      if (Date.now() > record.expires_at) {
        return res.status(401).json({ error: 'OTP has expired.' });
      }
    }

    db.prepare('DELETE FROM otp_store WHERE phone = ?').run(phone);

    db.prepare('INSERT INTO otp_logs (phone, action, ip_address) VALUES (?, ?, ?)')
      .run(phone, 'verified', req.ip);

    let user = db.prepare('SELECT * FROM users WHERE phone = ?').get(phone);
    let isNewUser = false;

    if (!user) {
      const result = db.prepare(
        'INSERT INTO users (name, role, phone) VALUES (?, ?, ?)'
      ).run('New User', 'student', phone);

      user = {
        id: result.lastInsertRowid,
        name: 'New User',
        role: 'student',
        phone: phone
      };
      isNewUser = true;
    }

    const sessionUser = {
      id: user.id,
      name: user.name,
      email: user.email,
      phone: user.phone,
      role: user.role
    };

    req.session.user = sessionUser;

    return res.status(200).json({ 
      message: 'Logged in successfully.', 
      user: sessionUser,
      isNewUser: isNewUser || !user.email
    });

  } catch (err) {
    console.error('Verify OTP error:', err);
    return res.status(500).json({ error: 'Failed to verify OTP.' });
  }
};

// POST /api/auth/complete-profile
exports.completeProfile = async (req, res) => {
  try {
    if (!req.session || !req.session.user) {
      return res.status(401).json({ error: 'Not authenticated.' });
    }

    const { name, email, role } = req.body;
    if (!name || !email) {
      return res.status(400).json({ error: 'Name and email are required.' });
    }

    const allowedRoles = ['student', 'owner'];
    const userRole = allowedRoles.includes(role) ? role : 'student';

    const db = getDB();

    const existing = db.prepare('SELECT id FROM users WHERE email = ? AND id != ?').get(email.toLowerCase().trim(), req.session.user.id);
    if (existing) {
      return res.status(409).json({ error: 'This email is already in use.' });
    }

    db.prepare('UPDATE users SET name = ?, email = ?, role = ? WHERE id = ?').run(
      name.trim(), email.toLowerCase().trim(), userRole, req.session.user.id
    );

    req.session.user.name = name.trim();
    req.session.user.email = email.toLowerCase().trim();
    req.session.user.role = userRole;

    return res.status(200).json({ message: 'Profile completed successfully.', user: req.session.user });
  } catch (err) {
    console.error('Complete profile error:', err);
    return res.status(500).json({ error: 'Failed to complete profile.' });
  }
};
