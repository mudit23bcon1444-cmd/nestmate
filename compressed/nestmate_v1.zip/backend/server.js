require('dotenv').config();
const express = require('express');
const session = require('express-session');
const path = require('path');
const { initDB } = require('./database');

const app = express();
const PORT = process.env.PORT || 5000;

// ─── Body Parsers ─────────────────────────────────────────────────────────────
app.use(express.json({limit:"16kb"}));
app.use(express.urlencoded({ extended: true,limit:"16kb" }));

// ─── Sessions ─────────────────────────────────────────────────────────────────
app.use(session({
  secret: process.env.SESSION_SECRET || 'nestmate-secret-key',
  resave: false,
  saveUninitialized: false,
  cookie: {
    maxAge: 1000 * 60 * 60 * 24, // 1 day
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production'
  }
}));

// ─── Guard List Property Page (Owner/Admin only) ──────────────────────────────
app.get(['/listing/code.html', '/listing', '/list_your_property_nestmate/code.html', '/list_your_property_nestmate'], (req, res, next) => {
  if (!req.session || !req.session.user || (req.session.user.role !== 'owner' && req.session.user.role !== 'admin')) {
    return res.redirect('/home/code.html');
  }
  res.sendFile(path.join(__dirname, 'public', 'listing', 'code.html'));
});

// ─── Static Files ─────────────────────────────────────────────────────────────
// Serve uploaded images
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Serve all frontend HTML pages from the public/ folder
app.use(express.static(path.join(__dirname, 'public')));

// ─── API Routes ───────────────────────────────────────────────────────────────
app.use('/api/auth',     require('./routes/auth'));
app.use('/api/listings', require('./routes/listings'));
app.use('/api/bookings', require('./routes/bookings'));
app.use('/api/admin',    require('./routes/admin'));

// ─── Health Check ─────────────────────────────────────────────────────────────
app.get('/api/health', (req, res) => {
  res.status(200).json({ status: 'ok', timestamp: new Date().toISOString() });
});

// Serve complete profile clean route
app.get('/complete-profile', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'complete_profile', 'code.html'));
});
app.get(['/otp-login', '/login'], (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'login', 'code.html'));
});

// ─── Fallback: serve home page for unknown routes ────────────────────────────
app.get('*', (req, res) => {
  // Only fall back for non-API routes
  if (req.path.startsWith('/api/')) {
    return res.status(404).json({ error: 'API route not found.' });
  }
  res.sendFile(path.join(__dirname, 'public', 'home', 'code.html'));
});

// ─── Error Handler ────────────────────────────────────────────────────────────
app.use((err, req, res, next) => {
  console.error('Unhandled ', err);
  res.status(500).json({ error: 'An unexpected error occurred.' });
});

// ─── Start ────────────────────────────────────────────────────────────────────
initDB();
app.listen(PORT, () => {
  console.log(`\n NestMate running on http://localhost:${PORT}`);
  console.log(`   Home page:       http://localhost:${PORT}/home/code.html`);
  console.log(`   Browse listings: http://localhost:${PORT}/browse/code.html`);
  console.log(`   Owner dashboard: http://localhost:${PORT}/dashboard/code.html`);
  console.log(`   Admin panel:     http://localhost:${PORT}/admin/code.html`);
  console.log(`\n   Admin login: admin@nestmate.com / admin123`);
  console.log(`   Demo owner:  owner@nestmate.com / owner123\n`);
});
