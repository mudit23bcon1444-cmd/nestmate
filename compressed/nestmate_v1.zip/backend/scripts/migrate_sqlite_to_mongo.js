require('dotenv').config({ path: require('path').join(__dirname, '..', '.env') });
const path = require('path');
const Database = require('better-sqlite3');
const connectDB = require('../config/db');

const User = require('../models/User');
const Listing = require('../models/Listing');
const Booking = require('../models/Booking');
const Enquiry = require('../models/Enquiry');
const AdminLog = require('../models/AdminLog');
const OtpStore = require('../models/OtpStore');
const OtpLog = require('../models/OtpLog');

async function migrate() {
  console.log('🚀 Starting SQLite to MongoDB migration...\n');
  await connectDB();

  const dbPath = path.join(__dirname, '..', 'nestmate.db');
  const sqliteDb = new Database(dbPath);

  // 1. Migrate Users
  const sqliteUsers = sqliteDb.prepare('SELECT * FROM users').all();
  console.log(`📦 Found ${sqliteUsers.length} users in SQLite.`);
  
  const userIdMap = new Map();

  for (const u of sqliteUsers) {
    const doc = await User.findOneAndUpdate(
      { legacy_sqlite_id: u.id },
      {
        legacy_sqlite_id: u.id,
        name: u.name,
        email: u.email ? u.email.toLowerCase().trim() : null,
        password: u.password || null,
        role: u.role || 'student',
        phone: u.phone || null
      },
      { upsert: true, new: true, setDefaultsOnInsert: true }
    );
    userIdMap.set(u.id, doc._id);
  }
  console.log(`✅ Migrated ${sqliteUsers.length} users to MongoDB.\n`);

  // 2. Migrate Listings
  const sqliteListings = sqliteDb.prepare('SELECT * FROM listings').all();
  console.log(`📦 Found ${sqliteListings.length} listings in SQLite.`);

  const listingIdMap = new Map();

  for (const l of sqliteListings) {
    const ownerObjectId = userIdMap.get(l.owner_id);
    if (!ownerObjectId) {
      console.warn(`⚠️ Warning: Owner ID ${l.owner_id} not found for listing #${l.id}. Skipping.`);
      continue;
    }

    const doc = await Listing.findOneAndUpdate(
      { legacy_sqlite_id: l.id },
      {
        legacy_sqlite_id: l.id,
        owner_id: ownerObjectId,
        title: l.title,
        location: l.location,
        price: l.price,
        description: l.description || null,
        amenities: l.amenities || null,
        image_path: l.image_path || null,
        is_approved: l.is_approved !== undefined ? l.is_approved : 0,
        is_available: l.is_available !== undefined ? l.is_available : 1,
        created_at: l.created_at ? new Date(l.created_at) : new Date()
      },
      { upsert: true, new: true, setDefaultsOnInsert: true }
    );
    listingIdMap.set(l.id, doc._id);
  }
  console.log(`✅ Migrated ${sqliteListings.length} listings to MongoDB.\n`);

  // 3. Migrate Bookings
  const sqliteBookings = sqliteDb.prepare('SELECT * FROM bookings').all();
  console.log(`📦 Found ${sqliteBookings.length} bookings in SQLite.`);

  for (const b of sqliteBookings) {
    const listingObjectId = listingIdMap.get(b.listing_id);
    const studentObjectId = userIdMap.get(b.student_id);

    if (!listingObjectId || !studentObjectId) {
      console.warn(`⚠️ Warning: Missing refs for booking #${b.id}. Skipping.`);
      continue;
    }

    await Booking.findOneAndUpdate(
      { legacy_sqlite_id: b.id },
      {
        legacy_sqlite_id: b.id,
        listing_id: listingObjectId,
        student_id: studentObjectId,
        move_in_date: b.move_in_date,
        status: b.status || 'pending',
        message: b.message || null,
        created_at: b.created_at ? new Date(b.created_at) : new Date()
      },
      { upsert: true, new: true, setDefaultsOnInsert: true }
    );
  }
  console.log(`✅ Migrated ${sqliteBookings.length} bookings to MongoDB.\n`);

  // 4. Migrate Enquiries
  const sqliteEnquiries = sqliteDb.prepare('SELECT * FROM enquiries').all();
  console.log(`📦 Found ${sqliteEnquiries.length} enquiries in SQLite.`);

  for (const e of sqliteEnquiries) {
    const listingObjectId = listingIdMap.get(e.listing_id);
    if (!listingObjectId) {
      console.warn(`⚠️ Warning: Missing listing ref for enquiry #${e.id}. Skipping.`);
      continue;
    }

    await Enquiry.findOneAndUpdate(
      { legacy_sqlite_id: e.id },
      {
        legacy_sqlite_id: e.id,
        listing_id: listingObjectId,
        student_name: e.student_name,
        student_phone: e.student_phone,
        message: e.message || '',
        created_at: e.created_at ? new Date(e.created_at) : new Date()
      },
      { upsert: true, new: true, setDefaultsOnInsert: true }
    );
  }
  console.log(`✅ Migrated ${sqliteEnquiries.length} enquiries to MongoDB.\n`);

  // 5. Migrate Admin Logs
  const sqliteAdminLogs = sqliteDb.prepare('SELECT * FROM admin_log').all();
  console.log(`📦 Found ${sqliteAdminLogs.length} admin logs in SQLite.`);

  for (const log of sqliteAdminLogs) {
    const doneByObjectId = log.done_by ? userIdMap.get(log.done_by) : null;

    await AdminLog.findOneAndUpdate(
      { legacy_sqlite_id: log.id },
      {
        legacy_sqlite_id: log.id,
        action: log.action,
        done_by: doneByObjectId,
        created_at: log.created_at ? new Date(log.created_at) : new Date()
      },
      { upsert: true, new: true, setDefaultsOnInsert: true }
    );
  }
  console.log(`✅ Migrated ${sqliteAdminLogs.length} admin logs to MongoDB.\n`);

  // 6. Migrate OTP Store
  const sqliteOtpStore = sqliteDb.prepare('SELECT * FROM otp_store').all();
  console.log(`📦 Found ${sqliteOtpStore.length} OTP store records in SQLite.`);

  for (const o of sqliteOtpStore) {
    await OtpStore.findOneAndUpdate(
      { legacy_sqlite_id: o.phone },
      {
        legacy_sqlite_id: o.phone,
        phone: o.phone,
        otp: o.otp,
        expires_at: o.expires_at,
        last_sent_at: o.last_sent_at,
        attempt_count: o.attempt_count || 0,
        locked_until: o.locked_until || 0
      },
      { upsert: true, new: true, setDefaultsOnInsert: true }
    );
  }
  console.log(`✅ Migrated ${sqliteOtpStore.length} OTP store records to MongoDB.\n`);

  // 7. Migrate OTP Logs
  const sqliteOtpLogs = sqliteDb.prepare('SELECT * FROM otp_logs').all();
  console.log(`📦 Found ${sqliteOtpLogs.length} OTP logs in SQLite.`);

  for (const ol of sqliteOtpLogs) {
    await OtpLog.findOneAndUpdate(
      { legacy_sqlite_id: ol.id },
      {
        legacy_sqlite_id: ol.id,
        phone: ol.phone,
        action: ol.action,
        ip_address: ol.ip_address,
        created_at: ol.created_at ? new Date(ol.created_at) : new Date()
      },
      { upsert: true, new: true, setDefaultsOnInsert: true }
    );
  }
  console.log(`✅ Migrated ${sqliteOtpLogs.length} OTP logs to MongoDB.\n`);

  console.log('🎉 Migration completed successfully!');
  process.exit(0);
}

migrate().catch(err => {
  console.error('❌ Migration failed:', err);
  process.exit(1);
});
