require('dotenv').config();
const express = require('express');
const cookieParser = require('cookie-parser');
const path = require('path');
const { initDB } = require('./database');

const app = express();
const PORT = process.env.PORT || 5000;

// ─── Body & Cookie Parsers ───────────────────────────────────────────────────
app.use(express.json({ limit: "16kb" }));
app.use(express.urlencoded({ extended: true, limit: "16kb" }));
app.use(cookieParser());

// ─── Listing Page Shortcut ───────────────────────────────────────────────────
app.get(['/listing/code.html', '/listing', '/list_your_property_nestmate/code.html', '/list_your_property_nestmate'], (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'listing', 'code.html'));
});

// ─── Static Files ─────────────────────────────────────────────────────────────
// Serve uploaded images
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Serve all frontend HTML pages from the public/ folder
app.use(express.static(path.join(__dirname, 'public')));

// ─── API Routes ───────────────────────────────────────────────────────────────
app.use('/api/auth',     require('./routes/auth'));
app.use('/api/listings', require('./routes/listings'));
app.use('/api/bookings', require('./routes/bookings'));
app.use('/api/admin',    require('./routes/admin'));

// ─── Health Check ─────────────────────────────────────────────────────────────
app.get('/api/health', (req, res) => {
  res.status(200).json({ status: 'ok', timestamp: new Date().toISOString() });
});

// Serve complete profile & login clean routes
app.get('/complete-profile', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'complete_profile', 'code.html'));
});
app.get(['/otp-login', '/login'], (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'login', 'code.html'));
});

// ─── Fallback: serve home page for unknown routes ────────────────────────────
app.get('*', (req, res) => {
  if (req.path.startsWith('/api/')) {
    return res.status(404).json({ error: 'API route not found.' });
  }
  res.sendFile(path.join(__dirname, 'public', 'home', 'code.html'));
});

// ─── Error Handler ────────────────────────────────────────────────────────────
app.use((err, req, res, next) => {
  console.error('Unhandled error:', err);
  res.status(500).json({ error: 'An unexpected error occurred.' });
});

// ─── Start ────────────────────────────────────────────────────────────────────
initDB();
app.listen(PORT, () => {
  console.log(`\n NestMate running on http://localhost:${PORT}`);
  console.log(`   Home page:       http://localhost:${PORT}/home/code.html`);
  console.log(`   Browse listings: http://localhost:${PORT}/browse/code.html`);
  console.log(`   Owner dashboard: http://localhost:${PORT}/dashboard/code.html`);
  console.log(`   Admin panel:     http://localhost:${PORT}/admin/code.html`);
  console.log(`\n   Admin login: admin@nestmate.com / admin123`);
  console.log(`   Demo owner:  owner@nestmate.com / owner123\n`);
});
